"""Turn evidence into findings.

Every detector reports at the highest tier its inputs allow and records a
:class:`~ayna.report.Check` either way, so a report always says what was
checked, what was clean, and what could not be assessed and why.

Thresholds are defaults calibrated on ayna's own synthetic faults
(``ayna validate``), not on CtD's trained models or on recordings. Treat them
as starting points; every one can be overridden.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, fields

import numpy as np

from . import __version__
from . import metrics as M
from . import probes as P
from .bundle import Bundle
from .report import Check, Finding, Report


@dataclass
class Thresholds:
    underfit_recoverable: float = 0.005     # recoverable info as a fraction of the model's own bits/spike
    underfit_recoverable_error: float = 0.02
    underfit_recoverable_z: float = 3.0     # and the per-trial gain must be this many SEs above zero
    underfit_baseline_margin: float = 0.0   # co-BPS must beat the reference model by this
    underfit_residual_ratio: float = 1.25   # evidence only since 0.2: shared residual vs shuffled null
    invention_cycle_warning: float = 0.90
    invention_cycle_error: float = 0.70
    invention_pc_r2: float = 0.50           # latent PCs below this are "not in the rates"
    min_pc_share: float = 0.01              # ignore latent PCs with less variance than this
    nullspace_rel_gain: float = 0.01
    readout_linearity: float = 0.90
    leakage_r2: float = 0.50
    rollout_gap: float = 0.25               # hold-state R² minus autonomous-rollout R²
    rollout_hold_min: float = 0.30          # only meaningful when the state persists
    rollout_horizon: int = 10
    inherited_warning: float = 0.70
    inherited_info: float = 0.40
    input_lags: int = 10
    gt_rate_r2: float = 0.90
    gt_recovery_r2: float = 0.90
    gt_state_r2: float = 0.90
    gt_input_r2: float = 0.50
    gt_inherited_r2: float = 0.70

    def update(self, overrides: dict) -> "Thresholds":
        names = {f.name: f.type for f in fields(self)}
        for key, value in overrides.items():
            if key not in names:
                raise KeyError(f"unknown threshold '{key}'; known: {', '.join(names)}")
            setattr(self, key, int(value) if names[key] in (int, "int") else float(value))
        return self


def scan(b: Bundle, thresholds: Thresholds | None = None, nonlinear_fallback: bool = True,
         seed: int = 0) -> Report:
    """Run every detector the bundle supports and return a :class:`Report`."""
    th = thresholds or Thresholds()
    metrics, findings, checks = {}, [], []
    ctx = _Context(b, th, metrics, findings, checks, seed)
    ctx.readout()
    ctx.underfitting()
    ctx.invention(nonlinear_fallback)
    ctx.misattribution()
    ctx.inherited()
    if b.has_ground_truth:
        ctx.ground_truth()
    else:
        for det in ("UNDERFITTING", "FEATURE_INVENTION", "DYNAMICAL_MISATTRIBUTION"):
            checks.append(Check(det, 2, "not_assessed", "no ground truth in bundle (expected for real data)"))
    return Report(
        name=b.name, summary=b.summary(), metrics=metrics, findings=findings, checks=checks,
        notes=list(b.notes), thresholds=asdict(th), version=__version__, source=b.source,
    )


class _Context:
    def __init__(self, b, th, metrics, findings, checks, seed):
        self.b, self.th, self.m, self.f, self.c, self.seed = b, th, metrics, findings, checks, seed
        self.lat_tr, self.lat_va = b.flat("latents", "train"), b.flat("latents", "val")
        self.rate_tr, self.rate_va = b.flat("rates", "train"), b.flat("rates", "val")
        self.linear_ok = True

    def check(self, det, tier, flagged, reason=""):
        self.c.append(Check(det, tier, "flagged" if flagged else "clean", reason))

    def skip(self, det, tier, reason):
        self.c.append(Check(det, tier, "not_assessed", reason))

    # ------------------------------------------------------------ readout
    def readout(self):
        b, th = self.b, self.th
        lin = M.readout_linearity(self.lat_tr, self.rate_tr, self.lat_va, self.rate_va)
        self.m["readout_linearity"] = lin
        self.linear_ok = lin >= th.readout_linearity
        if not self.linear_ok:
            self.f.append(Finding(
                "NONLINEAR_READOUT", "info", 0,
                what=(f"An affine map from latents explains only {lin:.0%} of log-rate variance on "
                      "validation trials. The linear metrics (cycle-consistency, readout null space) "
                      "assume the linear-exponential link and can mislead here; ayna switched to the "
                      "nonlinear cycle-consistency."),
                fix="Read FEATURE_INVENTION from the nonlinear version; treat linear numbers as indicative only.",
                evidence={"readout_linearity": lin}))
        self.check("NONLINEAR_READOUT", 0, not self.linear_ok)

    # --------------------------------------------------------- underfitting
    def underfitting(self):
        b, th = self.b, self.th
        signals, evidence, where = [], {}, []
        rec = P.recoverable_information(b, seed=self.seed)
        frac = rec["recoverable_fraction"]
        self.m["recoverable_fraction"] = frac
        evidence.update(rec)
        res = P.residual_structure(b, seed=self.seed)
        self.m["residual_ratio"] = res["residual_ratio"]
        evidence.update(res)
        severe = False
        self.m["recoverable_z"] = rec["recoverable_z"]
        if frac > th.underfit_recoverable and rec["recoverable_z"] >= th.underfit_recoverable_z:
            severe = frac > th.underfit_recoverable_error
            signals.append(
                f"other neurons' spikes still improve its predictions by {rec['recoverable_bits_per_spike']*1000:.2f} "
                f"millibits/spike ({frac:.1%} of the model's own {rec['recoverable_reference_bps']:.3f} bits/spike; "
                f"{rec['recoverable_split']}, trial-shuffled control subtracted, z = {rec['recoverable_z']:.1f})")
            if res["residual_ratio"] > th.underfit_residual_ratio:
                lo, hi = res["residual_peak_bins"]
                where.append(f"bins {lo}-{hi} of the trial; neurons "
                             f"{', '.join(map(str, res['residual_top_neurons']))} carry most of the shared residual")
        if b.heldout is not None:
            cobps = M.bits_per_spike(b.flat("rates", "val", b.heldout), b.flat("spikes", "val", b.heldout))
            base = P.baseline_co_bps(b, seed=self.seed)
            self.m["co_bps"] = cobps
            self.m["baseline_co_bps"] = base["baseline_co_bps"]
            evidence.update(base, co_bps=cobps)
            if cobps < base["baseline_co_bps"] + th.underfit_baseline_margin:
                signals.append(
                    f"co-BPS {cobps:.3f} does not beat a smoothed-spikes Poisson GLM "
                    f"({base['baseline_co_bps']:.3f})")
        else:
            self.skip("UNDERFITTING/co-BPS", 0, "no held-out neurons marked, so co-BPS and the baseline "
                      "comparison cannot run (recoverable information used a neuron split instead)")
        flagged = bool(signals)
        if flagged:
            sev = "error" if severe or len(signals) > 1 else "warning"
            self.f.append(Finding(
                "UNDERFITTING", sev, 0,
                what=("The spikes contain shared structure the model does not use: " + "; ".join(signals) + "."),
                where="; ".join(where),
                fix=("Increase capacity (latent size, generator units) or relax regularisation. If a "
                     "larger model only helps by inventing features, compare with `ayna select`. "
                     "Models without stochastic inputs cannot follow noise-driven fluctuations of the "
                     "circuit, so a small residual can persist at any size."),
                evidence=evidence))
        self.check("UNDERFITTING", 0, flagged)

    # ---------------------------------------------------- feature invention
    def invention(self, nonlinear_fallback):
        b, th = self.b, self.th
        cc, per_pc, share, kept = M.cycle_consistency(self.lat_tr, self.rate_tr, self.lat_va)
        self.m["cycle_consistency"] = cc
        null, gains, _ = M.readout_null_directions(self.lat_tr, self.rate_tr, th.nullspace_rel_gain)
        method = "linear"
        score = cc
        if not self.linear_ok:
            if nonlinear_fallback:
                score = M.nonlinear_cycle_consistency(self.lat_tr, self.rate_tr, self.lat_va, seed=self.seed)
                self.m["cycle_consistency_nonlinear"] = score
                method = "nonlinear"
            else:
                self.skip("FEATURE_INVENTION", 0, "readout is nonlinear and the nonlinear fallback was disabled")
                return
        bad = [i for i in range(len(per_pc)) if per_pc[i] < th.invention_pc_r2 and share[i] >= th.min_pc_share]
        bad_share = float(np.sum(share[bad])) if bad else 0.0
        bottleneck = b.meta.get("readout_bottleneck")
        if bottleneck and int(bottleneck) < b.n_latents:
            # e.g. LFADS: generator state -> low-dimensional factors -> rates. Directions outside the
            # factor space are silent by design, so absolute cycle-consistency is not comparable to
            # models without a bottleneck (CtD reports 0.3-0.5 for well-behaved LFADS models).
            self.f.append(Finding(
                "FEATURE_INVENTION", "info", 0,
                what=(f"Linear cycle-consistency is {score:.2f}, but this model reads its {b.n_latents} latent "
                      f"dimensions out through a {int(bottleneck)}-dimensional bottleneck, so directions outside "
                      "it are silent by design and the absolute value has no calibrated meaning. Compare "
                      "models of the same architecture on the same data with `ayna select`."),
                evidence={"cycle_consistency": score, "readout_bottleneck": int(bottleneck),
                          "per_pc_r2": [float(x) for x in per_pc],
                          "pc_variance_share": [float(x) for x in share]}))
            self.skip("FEATURE_INVENTION", 0, f"readout bottleneck ({int(bottleneck)} < {b.n_latents} latents): "
                      "cycle-consistency is comparative only")
            self.check("READOUT_NULLSPACE", 0, True)
            return
        flagged = score < th.invention_cycle_warning
        if flagged:
            sev = "error" if score < th.invention_cycle_error else "warning"
            where = (f"latent PCs {', '.join(str(i + 1) for i in bad)} ({bad_share:.0%} of latent variance)"
                     if bad and method == "linear" else "")
            self.f.append(Finding(
                "FEATURE_INVENTION", sev, 0,
                what=(f"{method.capitalize()} cycle-consistency is {score:.2f}: part of the inferred latent "
                      "activity cannot be regenerated from the model's own predicted rates. Latent structure "
                      "the rates do not reflect costs nothing in reconstruction, so it is unconstrained by "
                      "data -- a likely invented feature (CtD Fig 1G)."),
                where=where,
                fix=("Do not interpret those dimensions. Reduce latent size or regularise toward the "
                     "simplest model that keeps co-BPS (`ayna select` on a sweep)."),
                evidence={"cycle_consistency": score, "method": method,
                          "per_pc_r2": [float(x) for x in per_pc],
                          "pc_variance_share": [float(x) for x in share],
                          "readout_rank_kept": int(kept)}))
        self.check("FEATURE_INVENTION", 0, flagged)

        # readout null space: the mechanism, reported on its own when harmless so far
        null_share = float(np.sum(share[null])) if len(null) else 0.0
        if len(null) and not flagged and self.linear_ok:
            self.f.append(Finding(
                "READOUT_NULLSPACE", "info", 0,
                what=(f"{len(null)} latent direction(s) barely affect predicted rates (gain under "
                      f"{th.nullspace_rel_gain:.0%} of the strongest). They hold {null_share:.1%} of latent "
                      "variance now, so this is harmless today, but cycle-consistency cannot see "
                      "features that grow there."),
                where=f"latent PCs {', '.join(str(i + 1) for i in null)}",
                evidence={"null_pcs": [int(i) for i in null], "null_variance_share": null_share}))
        self.check("READOUT_NULLSPACE", 0, bool(len(null)))

    # ------------------------------------------------------- misattribution
    def misattribution(self):
        b, th = self.b, self.th
        det = "DYNAMICAL_MISATTRIBUTION"
        signals, evidence = [], {}
        if b.inputs is not None and b.inputs_kind == "inferred":
            leak = P.input_leakage(b)
            self.m["input_leakage_r2"] = leak["input_leakage_r2"]
            evidence.update(leak)
            hit = leak["input_leakage_r2"] > th.leakage_r2
            if b.meta.get("closed_loop"):
                # Declared closed-loop task: true inputs (sensory feedback) depend on the state, so
                # leakage cannot separate good inference from misattribution (RandomTarget, 0.3).
                if hit:
                    self.f.append(Finding(
                        det, "info", 0,
                        what=(f"Lag-1 input leakage is {leak['input_leakage_r2']:.2f}, but the task is declared "
                              "closed-loop: true inputs include feedback that depends on the state, so this is "
                              "expected whether or not inputs are misattributed. Not used as evidence; tier 1 "
                              "decides when a dynamics callable is attached."),
                        evidence=leak))
                self.skip(det, 0, "closed-loop task declared (meta['closed_loop']): leakage is expected "
                          "from sensory feedback")
            else:
                if hit:
                    dims = [i for i, v in enumerate(leak["input_leakage_per_dim"]) if v > th.leakage_r2]
                    signals.append(("leakage", f"the latent state one step *before* each input predicts it "
                                    f"(R² {leak['input_leakage_r2']:.2f} from {leak['input_leakage_pcs']} "
                                    f"latent PCs; input dims {', '.join(map(str, dims))})"))
                self.check(det, 0, hit)
        elif b.inputs is None:
            self.skip(det, 0, "bundle has no inputs; models without inferred inputs cannot misattribute to them")
        else:
            self.skip(det, 0, "inputs were supplied to the model, not inferred")

        if b.dynamics is not None and b.inputs is not None and b.inputs_kind == "supplied":
            # Supplied inputs are real: a state that depends on them (e.g. sensory feedback in a
            # closed-loop task) is not misattribution. Found on CtD RandomTarget in 0.3.
            self.skip(det, 1, "inputs were supplied to the model, so losing the state without them is "
                      "genuine input dependence, not misattribution")
        elif b.dynamics is not None:
            try:
                roll = P.autonomous_rollout(b, horizon=th.rollout_horizon, seed=self.seed)
            except Exception as exc:  # user code: report, never crash the scan
                roll = None
                self.skip(det, 1, f"dynamics callable raised {type(exc).__name__}: {exc}")
            if roll:
                self.m["rollout_r2_autonomous"] = roll["rollout_r2_autonomous"]
                self.m["rollout_r2_hold"] = roll["rollout_r2_hold"]
                self.m["rollout_gap"] = roll["rollout_r2_hold"] - roll["rollout_r2_autonomous"]
                evidence.update(roll)
                gap = roll["rollout_r2_hold"] - roll["rollout_r2_autonomous"]
                hit = roll["rollout_r2_hold"] >= th.rollout_hold_min and gap > th.rollout_gap
                if hit:
                    signals.append(("rollout", f"with inputs clamped to zero the model's own dynamics lose the "
                                    f"state: {th.rollout_horizon}-step R² {roll['rollout_r2_autonomous']:.2f} vs "
                                    f"{roll['rollout_r2_hold']:.2f} for simply holding it"))
                    fp = P.zero_input_fixed_points(b, seed=self.seed)
                    evidence.update(fp)
                    if fp.get("fixed_points") is not None:
                        evidence["occupied_regions"] = P.occupied_clusters(b, seed=self.seed)
                self.check(det, 1, hit)
        else:
            self.skip(det, 1, "no dynamics callable attached (Python API only: load_bundle(path, dynamics=f))")

        if signals:
            sev = "error" if len(signals) > 1 else "warning"
            extra = ""
            if evidence.get("stable_fixed_points") is not None and "occupied_regions" in evidence:
                extra = (f" Zero-input dynamics have {evidence['stable_fixed_points']} stable fixed point(s) "
                         f"while the latent state dwells in about {evidence['occupied_regions']} region(s).")
            self.f.append(Finding(
                det, sev, max(1 if s[0] == "rollout" else 0 for s in signals),
                what=("The inferred inputs appear to carry dynamics the model's generator should own: "
                      + "; ".join(s[1] for s in signals) + "." + extra
                      + " Reconstruction can be perfect in this failure mode (CtD Fig 1H, 6)."),
                fix=("Strengthen the input prior or penalty (e.g. LFADS controller KL) until inferred inputs "
                     "are sparse, and re-check. In closed-loop tasks, inputs may legitimately track state; "
                     "judge with task knowledge."),
                evidence=evidence, experimental=True))

    # ------------------------------------------------------ inherited input
    def inherited(self):
        b, th = self.b, self.th
        det = "INPUT_INHERITED_STRUCTURE"
        if b.inputs is None or b.inputs_kind != "supplied":
            self.skip(det, 0, "needs inputs supplied to the model")
            return
        res = P.input_inherited(b, n_lags=th.input_lags)
        r2 = res["input_filter_r2"]
        self.m["input_filter_r2"] = r2
        sev = "warning" if r2 >= th.inherited_warning else "info" if r2 >= th.inherited_info else None
        if sev:
            self.f.append(Finding(
                det, sev, 0,
                what=(f"{r2:.0%} of latent variance is a linear filter of the last {th.input_lags} bins of the "
                      "supplied inputs. That part would look right for any model that copies its inputs, so "
                      "good-looking latents say little about intrinsic dynamics here (CtD's RandomTarget case)."),
                fix=("Judge the model on what the inputs cannot explain: residual latents, held-out conditions, "
                     "or perturbations. Compare model classes on the input-unexplained part."),
                evidence=res))
        # 0.4: only a warning counts as flagged; info-level findings are reported but are not a verdict
        # (0.3 counted info as flagged while its truth line used the warning threshold).
        self.check(det, 0, sev == "warning")

    # --------------------------------------------------------- ground truth
    def ground_truth(self):
        b, th = self.b, self.th
        if b.true_rates is not None:
            r = M.rate_r2(b.flat("true_rates", "val"), self.rate_va)
            self.m["rate_r2"] = r
        else:
            r = None
        if b.true_latents is not None:
            zt_tr, zt_va = b.flat("true_latents", "train"), b.flat("true_latents", "val")
            s = M.state_r2(zt_tr, self.lat_tr, zt_va, self.lat_va)
            rec = M.recovery_r2(zt_tr, self.lat_tr, zt_va, self.lat_va)
            self.m["state_r2"], self.m["recovery_r2"] = s, rec
            under = (r is not None and r < th.gt_rate_r2) or rec < th.gt_recovery_r2
            self._gt("UNDERFITTING", under,
                     f"Rate R² {_f(r)}, latent recovery R² {rec:.3f} (flag if < {th.gt_rate_r2} / {th.gt_recovery_r2})")
            self._gt("FEATURE_INVENTION", s < th.gt_state_r2,
                     f"State R² {s:.3f} (flag if < {th.gt_state_r2})")
        else:
            self.skip("FEATURE_INVENTION", 2, "no true latents")
        if b.inputs is not None and b.inputs_kind == "inferred" and b.true_inputs is not None:
            U_tr, U_va = b.flat("inputs", "train"), b.flat("inputs", "val")
            ir = M.input_r2(b.flat("true_inputs", "train"), U_tr, b.flat("true_inputs", "val"), U_va)
            self.m["input_r2"] = ir
            if b.true_inputs_noiseless is not None:
                # CtD scores against the noisy inputs the teacher received; that caps Input R² at
                # the inputs' signal fraction (below 0.2 on 3BFF), so the truth line uses the
                # noiseless inputs the task actually specified.
                irn = M.input_r2(b.flat("true_inputs_noiseless", "train"), U_tr,
                                 b.flat("true_inputs_noiseless", "val"), U_va)
                self.m["input_r2_noiseless"] = irn
                self._gt("DYNAMICAL_MISATTRIBUTION", irn < th.gt_input_r2,
                         f"Input R² vs noiseless inputs {irn:.3f} (flag if < {th.gt_input_r2}); "
                         f"CtD's Input R² vs noisy inputs {ir:.3f}")
            else:
                self._gt("DYNAMICAL_MISATTRIBUTION", ir < th.gt_input_r2,
                         f"Input R² {ir:.3f} (flag if < {th.gt_input_r2})")
        else:
            self.skip("DYNAMICAL_MISATTRIBUTION", 2, "needs inferred inputs and true inputs")
        if b.inputs is not None and b.inputs_kind == "supplied" and b.true_latents is not None:
            res = P.input_inherited(b, n_lags=th.input_lags)
            tr2 = res.get("true_input_filter_r2", float("nan"))
            self.m["true_input_filter_r2"] = tr2
            self._gt("INPUT_INHERITED_STRUCTURE", tr2 >= th.gt_inherited_r2,
                     f"true latents are {tr2:.0%} explained by recent inputs")

    def _gt(self, det, flagged, text):
        self.check(det, 2, flagged)
        if flagged:
            self.f.append(Finding(det, "error", 2, what="confirmed: " + text))
        else:
            self.f.append(Finding(det, "info", 2, what="not present: " + text))


def _f(x):
    return "n/a" if x is None else f"{x:.3f}"
